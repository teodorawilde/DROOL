﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MEFMvc.ViewModels
{
    public class Exchange
    {
        public string ExchangeName { get; set; }
    }
}